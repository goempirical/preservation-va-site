=== Give - Recurring Donations ===
Contributors: wordimpress, dlocc, ramiy
Tags: donations, donation, ecommerce, e-commerce, fundraising, fundraiser, paymill, gateway
Requires at least: 4.8
Tested up to: 4.9
Stable tag: 1.7.1
Requires Give: 2.1.7
License: GPLv3
License URI: https://opensource.org/licenses/GPL-3.0

Create powerful subscription based donations with the Give Recurring Donation Add-on.

== Description ==

This plugin requires the Give plugin activated to function properly. When activated, it adds the ability to accept recurring (subscription) donations to various payment gateways such as PayPal Standard, Stripe, PayPal Pro, and more.

== Installation ==

= Minimum Requirements =

* WordPress 4.8 or greater
* PHP version 5.3 or greater
* MySQL version 5.0 or greater
* Some payment gateways require fsockopen support (for IPN access)

= Automatic installation =

Automatic installation is the easiest option as WordPress handles the file transfers itself and you don't need to leave your web browser. To do an automatic install of Give, log in to your WordPress dashboard, navigate to the Plugins menu and click Add New.

In the search field type "Give" and click Search Plugins. Once you have found the plugin you can view details about it such as the the point release, rating and description. Most importantly of course, you can install it by simply clicking "Install Now".

= Manual installation =

The manual installation method involves downloading our donation plugin and uploading it to your server via your favorite FTP application. The WordPress codex contains [instructions on how to do this here](http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation).

= Updating =

Automatic updates should work like a charm; as always though, ensure you backup your site just in case.

== Changelog ==

= 1.7.1: July 5th, 2018 =
* Fix: Resolved conflict with Stripe 2.0.6+ causing the Update Payment Method for recurring to have a JS error.
* Fix: Ensure that the word "Donation" doesn't appear incorrectly after the recurring donation checkbox.

= 1.7.0: June 28th, 2018 =
* New: Donors now have the ability to adjust the credit card information (within supported gateways) for their subscriptions so that if a card expires or they would like to use a new card they can update it through your website.
* New: Additional emails have been added so that you can send your donors reminders when their subscription is renewing, completing, and cancelling.
* New: The export donation tool will now export subscription related information such as billing period, times, and frequency.
* New: Now you can modify your donation form goals to only account for subscriptions. For example, "$50 per month raised toward a goal of $500 per month".
* New: Added an indication at the bottom donation amount field that the donation they are going to give is recurring to improve the donor's awareness and experience.
* Tweak: Increased the IPN window time for PayPal Pro to account for delays of renewals being sent from PayPal to your website so they can record properly.
* Fix: Resolved an error with Stripe's webhook preventing renewals from being processed properly. Webhooks now process renewals correctly and payments are added again. No more manual syncing is necessary.
* Fix: The "Renewals" payments list screen is now properly accessable from the payments view in wp-admin.
* Fix: The {date} email tag was returning the date of the original subscription payment within the renewal email notification. The email tag now displays the appropriate renewal date.
* Fix: The email access verification text for the subscriptions page displays different content than the donation history page as to not confuse the donor or redirect them to the donor history page.
* Fix: In wp-admin when drag-and-dropping donation form levels the recurring options could be lost.
* Fix: Removed the "#" prefix from the subscriptions ID within the wp-admin subscription list table to better match Give Core.
* Fix: Improved the way recurring fields are displayed within the donation form admin screens on fresh installs to help admins setup their donation forms.
* Fix: Admin UI improvement for the Subscription Information metabox within the payment details screen. If there were many subscriptions the scrolling was getting thrown off.
* Fix: Recurring now prevents donation forms from sending more than 20 metadata keys to Stripe. The limit is 20 and if it goes over that limit an API error would occurr.

= 1.6.1: May 10th, 2018 =
* Fix: Resolved Stripe Error with Form Field Manager long labels or meta keys being rejected by Stripe's API. They are now trimmed to the appropriate length before being sent over.
* Fix: Resolved a PHP notice from displaying when deleting a donation.
* Fix: Updated several SQL queries to be using Give 2.0+ paymentmeta table.

= 1.6: May 2nd, 2018 =
* New: Added the ability for admins to set recurring frequencies much more flexibly. It's now easy to set quarterly, semi-annually, bi-monthly, and many other giving frequencies.
* New: Added the ability to accept recurring donations through Stripe + Plaid (ACH).
* New: Added the ability to accept recurring donations through Stripe's Google and Apple Pay integration.
* New: Exporting donations in Give Core 2.1 now has support to added columns for recurring donation data such as payment type (one time, renewal, subscription).
* New: Stripe now passes meta data to the gateway when a recurring subscription is created.
* New: Added pagination to the [give_subscriptions] shortcode for donors with many subscriptions.
* Fix: Improved caching strategy for subscription based queries.
* Fix: Adding Multiple Shortcodes on same page should not ask for login multiple times.
* Fix: Display frequency tag correctly for PayPal Pro donations.
* Fix: The {subscriptions_completed} email tag should output correct data for one time donations.

= 1.5.7: February 20th, 2018 =
* Tweak: The {subscription_frequency} now outputs "one-time" for non-recurring donations rather than nothing.
* Fix: A PHP notice when making a donation would display if you have WP_DEBUG turned on.

= 1.5.6: February 19th, 2018 =
* Fix: Custom amounts can now be either recurring or non-recurring based on your giving preference.
* Fix: The "Subscriptions Page" setting was missing in Give's general settings due a change in the previous version. It has now been restored.
* Fix: PHP warning "invalid subscription_id error" while donating and using the {subscription_frequency} email tag.

= 1.5.5: February 1st, 2018 =
* Tweak: Improved internationalization of the donor's choice checkbox language string.
* Fix: Improved SQL query structure for DB upgrade having issues on some database environments.
* Fix: PHP notice when clicking on a custom amount level.

= 1.5.4: January 12th, 2018 =
* Fix: The update routine supposed to be release in 1.5.3 wasn't properly merged therefore we need this new release to ensure it goes out to everyone as expected.

= 1.5.3: January 3rd, 2018 =
* Fix: Resolved issue with upgrade routine not displaying and running correctly for older versions updating to the latest version.
* Fix: The {subscription_frequency} now returns the text "One Time" when it's not a recurring donation rather than nothing at all.

= 1.5.2: January 3rd, 2018 =
* New: There is now a hidden field that can be used by other plugin authers to determine whether the given donation was recurring or not.
* Fix: Currency formatting was incorrect (too many decimal values would show) for the recurring helper text when choosing a recurring level.

= 1.5.1: December 26th, 2017 =
* New: Added bulk actions within the subscriptions listing page in wp-admin.
* Fix: An incorrect number of decimals would display if using admin defined recurring donations with the helper text enabled.
* Fix: The wp-admin conditional field logic was incorrect for set donation forms recurring option fields. This would lead to admin confusion when creating new recurring forms and has been resolved.
* Fix: If using admin choice multi-level donations certain non-recurring levels would be incorrectly interpretted as recurring which could cause donor confusion on the receipt page.
* Fix: Stripe would send the subscription cancelled email twice if the donor cancelled the subscription themselves and when the subscription cancelled in the gateway. This has been resolved so that the email will only send once when the subscription is cancelled.
* Fix: When hovering over a subscription report the income was missing a currency symbol.
* Fix: Minor PHP notices when making a subscription donation if using certain version of Give core.
* Tweak: Various updates for the upcoming Give 2.0 release.
* Tweak: Added page title to the "Recurring Donations" page on the wp-admin page listing screen.

= 1.5: November 21st, 2017 =
* New: Now you can provide your donors with the option to select their recurring subscription giving frequency. This provides more flexibility to their giving choices and should help increase recurring subscription conversions.
* Fix: Renewals would show incorrectly when filtering on the donations listing page.
* Fix: Multi-level recurring forms with dropdown were not updating the recurring amount description correctly.
* Fix: Conflict with manual donations and 1.4.x of recurring.

= 1.4.2: November 21st, 2017 =
* Fix: Resolved issue with PHP 5.2 - 5.4 causing PHP error when the plugin attempts to load.

= 1.4.1: November 20th, 2017 =
* Fix: Resolved hook priority issue preventing "Sync" and "Cancel" subscription options from displaying properly in wp-admin.

= 1.4: November 20th, 2017 =
* New: You now have the ability to add renewal payments manually to subscriptions within the subscription details screen in wp-admin.
* New: Subscription profile IDs are now linked to the gateway subscription profile for easy access.
* New: Added foundation of PHP unit tests for easier bug detection, increased code coverage, and quality.
* New: Added a filter for PayPal Payflow IPN window timeframe called "give_recurring_payflow_ipn_window_timeframe" and increased the amount of time threshold to better match recurring payments.
* New: Added explanatory text for recurring admin choice forms that appears below levels to make final donation more clear to the donor.
* New: Recurring now adds an API endpoint to the Give core API for developers to work with.
* New: Admins now have the ability to search through the subscription list as well as filter by date and donation form.
* New: Moved the "Subscriptions Page" settings field under Settings > General it is generated by default for new installs. If you haven't set it yet, it's a good idea to set it.
* Tweak: Adjusted code to use GIVE_RECURRING_* constants so developers can flexibly override them for various requirements. Thanks @JJJ
* Tweak: Removed usage of Give core deprecated hooks causing PHP notices when debug is enabled.
* Tweak: Donation History page now has a "recurring" indicator for donors to more easily which donations are recurring compared to non-recurring.
* Tweak: Notices that display are now standardized to use the Give core notices class.
* Tweak: Changed the default option for "Donor's Choice" checkbox to be unchecked by default.
* Tweak: Updated the output for when a donation form is recurring admin defined set donation so that the "Donate Now" button always appears below the main.
* Tweak: Authorize.net now uses webhooks for the main pingback mechanism rather than the unreliable Silent Post URL which is now the fallback.
* Tweak: The Renewal reports  graph now labels data as "Renewals" rather than "Subscriptions".
* Tweak: Improved the settings page layout to be better organized.
* Fix: The dashboard stats widget and other reports not properly count renewal donations amounts and number of donations properly.
* Fix: PayPal Pro Gateway (NVP API) - Request body bug with sending state in place of country causing API issues. Thanks @wesdunn
* Fix: Added security with additional nonces throughout plugin.
* Fix: When a custom recurring amount is donated for a multi-level form, the plugin didn't properly show the "custom" as the label in Donations (admin dashboard), instead it showed the label of the first level of the multi level donation form.
* Fix: A donation form's recurring options were not correctly show/hiding sub-fields on the edit donation form screen within wp-admin.
* Fix: If special characters were sent to PayPal Pro in the PROFILENAME field an error would return. Now the field is sanitized so no special characters should ever be sent to prevent this error.
* Fix: Removed duplicate Give API fields appearing under the user profile.
* Fix: Preventing undimissible JS alert when setting a recurring donations times to 1.
* Fix: Recurring specific email tags were not working in the core donation receipt email.
* Fix: When a renewal donation is added, it is now being properly reflected in the list at Donations > Donors > Total donated in both the number of donations or the total amount donated columns.
* Fix: Renewal donations are now properly displayed when filtering in wp-admin within the donations listing screen.
* Fix: Pagination reliability is now fixed for when you page through the subscriptions list screen under Donations > Subscriptions in wp-admin.
* Fix: The Renewal Donations report now matches the Income report found in Give 1.8+.
* Fix: Issue where some donors couldn't cancel their subscriptions due to being a guest on the site.
* Fix: If you disabled guest donations on a donor's choice recurring form with email access disabled, the registration/login fields would be still toggle, but would be incorrectly required with recurring unchecked.
* Fix: Authorize.net - a renewal would incorreclty be created a day after the first donation for some subscriptions due to a delay with the Silent Post URL.
* Fix: The plugin now will delete all data if the Give core settings is set to delete all data on uninstall.
* Fix: The give_is_form_recurring() would return false positives incorrectly.

= 1.3.1 =
* New: Recurring gateways that add API keys now use Give core's api_key field type to help prevent viewing of API key content.
* Fix: Prevent errors when attempting to activate plugin with an older unsupported Give version or Give is not active at all.
* Various bug fixes and code improvements.

= 1.3 =
* New: Introduced the Subscription Synchronizer tool. Subscription can get out of sync with the gateway for a variety of data. This tool allows you to connect to the specific subscription's gateway and sync the transactions and subscription information so that the data is no longer out of sync.
* New: A new subscriptions column now appears under WP-Admin > Donations > Donors so you can quickly see who is a subscriber and how many subscriptions they have. You can also click on the it to see that donor's specific subscriptions.
* New: is_subscription_valid() method added to Give_Recurring_Gateway().
* Fix: Authorize.net now properly processes the MD5 Hash option via Silent Post URL. This means subscription renewals should come in fine now from the Authorize.net API with this option enabled.
* Fix: PayPal Payments Pro now properly process Instant Payment Notifications from PayPal to accept renewals. Use the synchronizer tool if your current subscriptions are out of date.
* Fix: Renewal emails now have a proper heading for the receipt that is emailed.
* Fix: Don't allow recurring checkboxes to bump to two lines for certain themes like TwentySeventeen.
* Various bug fixes and minor text updates.

= 1.2.3 =
* New: Added functionality to require that Give core be active in order to use the plugin. #301
* Fix: Logs filling with "Error Processing IPN Transaction" incorrectly for non-recurring payments. #293
* Fix: Refactored JS for how the recurring checkbox toggle displays required fields. - https://github.com/WordImpress/Give-Recurring-Donations/pull/303
* Fix: Authorize.net Subscription names need to be limited to 50 characters. #298

= 1.2.2 =
* New: Pass the billing address information to Authorize.net about the donor when creating the subscription if present. #271
* New: Better error reporting for Authorize.net. #271
* New: Method to confirm whether the Payflow recurring feature is enabled at the gateway to better ensure the subscription is created successfully. #288
* New: Subscription status indicator icon added to Donations > Subscriptions > Subscription Details page. #132
* Fix: Intermittent issue with the donor's subscription cancel option displaying properly due to an issue with the PayPal Payflow gateway cancel logic. #260
* Fix: Resolved translation strings without textdomains or incorrect text domains for better translations. #275

= 1.2.1 =
* Fix: License activation notice would improperly display even though the license was activated when the admin viewed the Recurring Donations settings tab. #265

= 1.2 =
* New: Support for PayPal Payments Pro (Payflow). #256
* New: Support for the PayPal REST API. #224
* New: The ability to filter subscriptions by status under Donations > Subscriptions
* New: The ability to edit a number of subscription detail fields including profile ID, expiration date, and subscription status
* New: Improved UI for [give_subscriptions] shortcode and also customizable attributes. #143
* New: Filter "give_recurring_multilevel_text_separator" to control multi-level separator between level text and recurring duration text. #142
* New: Added span wrapped tag to recurring language in multi-level buttons for easier styling. #142
* New: Allow the admin to delete or cancel renewal in the subscription details. #204
* New: New form for adding manual renewal payments added to individual subscription details admin page. #205
* New: Stripe now supports refunding and cancelling subscriptions from the donation details screen. #239
* Tweak: Consolidate subscriptions listing column & improved UI in WP-admin under Donations > Subscriptions. #251
* Tweak: Subscription donations are now referred to as "Renewals" for better clarity and easier understanding of the status. #215
* Fix: When Give is opening the donation form in a modal, the "Make this donation recurring" Donor's choice checkbox appears before the button. #253
* Fix: Properly show/hide the "Recurring Opt-in Default" field in the admin when toggling recurring options
* Fix: Incorrect false negative in conditional check for whether a donation form is recurring is_recurring() method
* Fix: Issue with checking if a Transaction payment is a Subscription parent payment which was causing the recurring label to be incorrectly output on the parent payments' transaction. #214
* Fix: Reports filter field not displayed on the Recurring reports sections. #211
* Fix: Reports tooltips not properly formatted. #217
* Fix: Donor details renewal stat incorrect. #245
* Fix: Renewal date incorrectly calculating for certain donation form configurations. #201
* Fix: Multiple Donors Choice Recurring Forms cause first Checkbox to always be selected. #254
* Fix: Require the last name field for Authorize.net - the gateway requires that the last name be passed when creating subscriptions. #262

= 1.1.1 =
* Fix: PHP fatal error for some hosting configurations "Can't use function return value in write context". #192
* New: New link to plugin settings page with new base name constant. #190

= 1.1 =
* New: Don't require a login or registration for subscription donations when email access is enabled. #169
* New: Show a login form for [give_subscriptions] shortcode for non-logged-in users. #163
* New: Donation form option for admins to set whether subscription checkbox is checked or unchecked by default. #162
* Tweak: Provide Statement Descriptor when Creating Stripe Plans. #164
* Tweak: Don't register post status within Recurring; it's already in Core. #174
* UX: Added scrolling capability to subscription parent payments' metabox because it was getting too long for ongoing subscriptions. #130
* Fix: PHP Fatal error when Stripe event is not returned. #176
* Fix: PayPal Pro Gateway message issue "Something has gone wrong, please try again" response . #177
* Fix: Blank notice appears when updating / saving settings in Give. #171

= 1.0.1 =
* Fix: Security fix added to prevent non-subscribers from seeing others subscriptions within the [give_subscriptions] shortcode.

= 1.0 =
* Initial plugin release. Yippee!
